import cv2
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import RPi.GPIO as GPIO
import time
import csv
import datetime

GPIO.setwarnings(False)

class App:
    def __init__(self, window):
        self.window = window
        self.window.title("Motion Detection")

        # create dropdown list to select video source
        self.video_source_options = ["0", "1"]
        self.selected_video_source = tk.StringVar(window, value=self.video_source_options[0])
        self.dropdown = tk.OptionMenu(window, self.selected_video_source, *self.video_source_options)
        self.dropdown.pack()
        
        # create the CSV file and write the header row
        self.csv_file = open('human_detection_log.csv', mode='w')
        self.csv_writer = csv.writer(self.csv_file)
        self.csv_writer.writerow(['Date', 'Time'])
        
        # open default video source
        self.vid = cv2.VideoCapture(int(self.selected_video_source.get()))

        # create a canvas that can fit the above video source size
        self.canvas = tk.Canvas(window, width=self.vid.get(cv2.CAP_PROP_FRAME_WIDTH),
                                height=self.vid.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.canvas.pack()

        # create buttons
        self.btn_start = tk.Button(window, text="Start", width=20, command=self.start)
        self.btn_start.pack(side=tk.LEFT)
        self.btn_stop = tk.Button(window, text="Stop", width=20, command=self.stop)
        self.btn_stop.pack(side=tk.LEFT)
        self.btn_close = tk.Button(window, text="Close", width=20, command=self.close)
        self.btn_close.pack(side=tk.LEFT)

        # set up motion detection
        self.motion_detector = cv2.createBackgroundSubtractorMOG2(history=100, varThreshold=50)

        # set up face detection
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

        self.delay = 15
        self.photo = None
        self.buzzer_pin = 18  # the GPIO pin number where the buzzer is connected
        self.buzzer_duration = 0.1  # the duration of the buzzer sound (in seconds)
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.buzzer_pin, GPIO.OUT)
        self.update()

        self.window.mainloop()

    def start(self):
        # release the previous video source
        self.vid.release()

        # open the selected video source
        self.vid = cv2.VideoCapture(int(self.selected_video_source.get()))

    def stop(self):
        # release the video source
        self.vid.release()

    def close(self):
        # release the video source and close the window
        self.vid.release()
        self.window.destroy()
        self.csv_file.close()

    def update(self):
        # get a frame from the video source
        ret, frame = self.vid.read()

        if ret:
            # detect motion in the frame
            fgmask = self.motion_detector.apply(frame)
            count = cv2.countNonZero(fgmask)

            # if motion is detected, check if a face is present
            if count > 10:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                faces = self.face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
                # convert the frame to PIL format and show it on the canvas
                self.photo = ImageTk.PhotoImage(image=Image.fromarray(frame))
                self.canvas.create_image(0, 0, image=self.photo, anchor=tk.NW)
                if len(faces) > 0:
                    now = datetime.datetime.now()
                    date = now.date().strftime('%Y-%m-%d')
                    time = now.time().strftime('%H:%M:%S')
                    self.csv_writer.writerow([date, time])
                    # turn on the buzzer
                    GPIO.output(self.buzzer_pin, GPIO.HIGH)
                    # show the message box
                    messagebox.showinfo("Alert!!!", "Motion detected")
                    # wait
                    # turn off the buzzer
                    GPIO.output(self.buzzer_pin, GPIO.LOW)
                    
                else:
		    # turn off the buzzer
                    GPIO.output(self.buzzer_pin, GPIO.LOW)
                    # convert the frame to PIL format and show it on the canvas
                    self.photo = ImageTk.PhotoImage(image=Image.fromarray(frame))
                    self.canvas.create_image(0, 0, image=self.photo, anchor=tk.NW)

        self.window.after(self.delay, self.update)

# create the application
App(tk.Tk())

